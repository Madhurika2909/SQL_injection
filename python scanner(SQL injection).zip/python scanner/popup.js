document.getElementById("scanBtn").addEventListener("click", function () {
    const urlInput = document.getElementById("urlInput").value.trim();

    if (!urlInput) {
        document.getElementById("results").innerHTML = "<p style='color: red;'>⚠️ Please enter a valid URL!</p>";
        return;
    }

    chrome.runtime.sendMessage({ action: "scan_sql", url: urlInput }, function (response) {
        document.getElementById("results").innerHTML = response?.message || "No response from scanner.";
    });
});
