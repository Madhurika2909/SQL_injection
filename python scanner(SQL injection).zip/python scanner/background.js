chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "scan_sql") {
        scanWebsite(request.url).then((message) => sendResponse({ message }));
        return true;
    }
});

async function scanWebsite(url) {
    try {
        const response = await fetch(url);
        const text = await response.text();

        const vulnerabilities = [
            "quoted string not properly terminated",
            "unclosed quotation mark after the character string",
            "you have an error in your SQL syntax"
        ];

        for (const vuln of vulnerabilities) {
            if (text.toLowerCase().includes(vuln)) {
                return `<p style="color: red;">⚠️ SQL Injection vulnerability detected on ${url}!</p>`;
            }
        }

        return `<p style="color: green;">✅ No SQL vulnerabilities found on ${url}.</p>`;
    } catch (error) {
        return `<p style="color: yellow;">⚠️ Error scanning ${url}: ${error}</p>`;
    }
}
